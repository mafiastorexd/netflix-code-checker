import imaplib, email, re
from bs4 import BeautifulSoup            # pip install beautifulsoup4
from email.header import decode_header
from email.utils import parsedate_to_datetime
from datetime import datetime, timedelta, timezone

# 👇 apni Gmail ID & 16‑digit App Password yahan bhar do:
GMAIL_USER = "samonlineott.shop@gmail.com"
GMAIL_PASS = "lzek saxg mgyc vndl"

LOOKBACK_MIN = 15
SUBJECT_PAT  = re.compile(r"(sign[\s-]?in code|reset your password)", re.I)
CODE_PAT     = re.compile(r"(?:\\d[\\s-]?){6}")             # 6 digits (space/dash allowed)
RESET_LINK   = re.compile(r"https://www\\.netflix\\.com/.+reset.+", re.I)

def _decode(hdr):
    txt, enc = decode_header(hdr)[0]
    return txt.decode(enc or "utf-8") if isinstance(txt, bytes) else txt

def _plain(text_or_html):
    soup = BeautifulSoup(text_or_html, "html.parser")
    for br in soup.find_all("br"): br.replace_with("\n")
    return soup.get_text("\n")

def fetch_latest_netflix_mail(target_email: str) -> dict | None:
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=LOOKBACK_MIN)
    since  = cutoff.strftime("%d-%b-%Y")

    try:
        imap = imaplib.IMAP4_SSL("imap.gmail.com")
        imap.login(GMAIL_USER, GMAIL_PASS)
        imap.select("inbox")

        ok, ids = imap.search(None, f'(SINCE "{since}")')
        if ok != "OK": return {"error": "IMAP search failed"}

        for num in reversed(ids[0].split()[-150:]):        # latest 150 msgs
            _, data = imap.fetch(num, "(RFC822)")
            msg = email.message_from_bytes(data[0][1])

            subject = _decode(msg.get("Subject", ""))
            if not SUBJECT_PAT.search(subject):            # sign‑in / reset only
                continue

            if target_email.lower() not in msg.as_string().lower():
                continue

            msg_dt = parsedate_to_datetime(msg["Date"])
            if msg_dt.tzinfo is None:
                msg_dt = msg_dt.replace(tzinfo=timezone.utc)
            if msg_dt < cutoff:
                continue

            html_body = None
            plain_body = None
            if msg.is_multipart():
                for part in msg.walk():
                    ctype = part.get_content_type()
                    if ctype == "text/html" and html_body is None:
                        html_body = part.get_payload(decode=True).decode(errors="ignore")
                    elif ctype == "text/plain" and plain_body is None:
                        plain_body = part.get_payload(decode=True).decode(errors="ignore")
            else:
                if msg.get_content_type() == "text/html":
                    html_body = msg.get_payload(decode=True).decode(errors="ignore")
                else:
                    plain_body = msg.get_payload(decode=True).decode(errors="ignore")

            if html_body is None and plain_body:
                html_body = plain_body

            plain_for_regex = _plain(html_body)

            code_match   = CODE_PAT.search(plain_for_regex)
            reset_match  = RESET_LINK.search(plain_for_regex)

            imap.logout()
            return {
                "sender"        : msg.get("From"),
                "subject"       : subject,
                "body_html"     : html_body,
                "extracted_code": re.sub(r"\\D", "", code_match.group()) if code_match else None,
                "reset_link"    : reset_match.group(0) if reset_match else None,
            }

        imap.logout()
        return {"error": "No recent Netflix sign‑in / reset email found"}
    except imaplib.IMAP4.error:
        return {"error": "IMAP auth failed — check GMAIL_USER / APP PASSWORD"}
    except Exception as e:
        return {"error": str(e)}
