from flask import Flask, render_template, request
from gmail_utils import fetch_latest_netflix_mail

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        email = request.form.get("email")
        try:
            result = fetch_latest_netflix_mail(email)
        except Exception as e:
            result = {"error": str(e)}
    return render_template("index.html", result=result)

if __name__ == "__main__":
    # debug=True sirf local testing ke liye, deploy pe hata dena
    app.run(debug=True)
